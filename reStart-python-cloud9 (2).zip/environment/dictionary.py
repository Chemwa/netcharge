learners = dict()
print(learners)
learners["name"] = "Lewis"
print(learners)

squares = [ value ** 2 for value in range(1,5)]
print(squares)