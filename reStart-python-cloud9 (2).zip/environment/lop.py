counter = 0
 
while(counter <= 3):
    print(f"I love learning python {counter}")
    counter = counter + 1
    
Learners=["Nancy","Mercy","Boss"]
Ages=[4,8,10]
Composite=["Jared",65, "Brunno",30]

for Learner in Learners:
    print(Learner)
    
    
    
